/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModeloBD;
import java.sql.*;
import java.util.ArrayList;
import Modelo.Evento;
import java.time.LocalDate;
import java.time.LocalTime;
/**
 *
 * @author 1GDAW04
 */
public class TablaEventos {
    private Connection con;
            
    public TablaEventos(Connection con){
        this.con=con;
    }
    public void insertar(Evento e) throws Exception{
        String plantilla = "Insert into evento values (?,?,?,?,?,?);";
        PreparedStatement ps = con.prepareStatement(plantilla);
        ps.setString(1, e.getNombre());
        ps.setString(2, e.getLugar());
        ps.setTime(3, java.sql.Time.valueOf(e.getHoraInicio()));
        ps.setTime(4, java.sql.Time.valueOf(e.getHoraFin()));
        ps.setDate(5, java.sql.Date.valueOf(e.getFecha()));
        ps.setInt(6, e.getNumAsistentes());
        
        int n = ps.executeUpdate();
        ps.close();
        if (n !=1)
            throw new Exception ("El número de filas insertadas no es uno");
    }

    public void cancelar(Evento e) throws Exception{
        String plantilla = "Delete from evento where Nombre=?;";
        PreparedStatement ps = con.prepareStatement(plantilla);
        ps.setString(1, e.getNombre());
        
        int n = ps.executeUpdate();
        ps.close();
        if (n != 1)
            throw new Exception("El número de filas borradas no es uno");
    }
    
    public void actualizar (Evento e) throws Exception{
        String plantilla = "Update evento set ";//INACABADO
        PreparedStatement ps = con.prepareStatement(plantilla);
        
        int n = ps.executeUpdate();
        ps.close();
        if (n != 1)
            throw new Exception("El número de filas borradas no es uno");
    }
}
