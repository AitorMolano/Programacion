/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package basededatos2;
import Vistas.*;
import Modelo.*;
import ModeloBD.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
/**
 *
 * @author 1GDAW04
 */
public class BaseDeDatos2 {
    private static BaseDatos bd;
    private static V1 v1;
    private static VCrearEvento vce;
    private static Evento evento;
    private static TablaEventos tEv;
    private static VCancelar vCanc;
    private static VModificar vMod;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try{
            bd = new BaseDatos();
            bd.conectar();
            tEv = new TablaEventos(bd.getCon());
            
            v1=new V1();
            v1.setVisible(true);
            v1.setLocationRelativeTo(null);
        }
        catch (Exception e){
            bd.desconectar();
        }
    }
    
    public static void insertarEvento(String nombre, String lugar, LocalTime horaInicio, LocalTime horaFin, LocalDate fecha, int numAsistentes) throws Exception{
        evento = new Evento(nombre, lugar, horaInicio, horaFin, fecha, numAsistentes);
        tEv.insertar(evento);
    }
    
    public static void borrarEvento() throws Exception{
        tEv.cancelar(evento);
    }
    
    public static void modificarEvento(String nombre) throws Exception{
        
    }
    
    public static void salir(){
        System.exit(0);
    }
    
    public static void ventanaCrear(){
        vce = new VCrearEvento();
        vce.setVisible(true);
        vce.setLocationRelativeTo(null);
    }
    
    public static void volverMain(javax.swing.JFrame v){
        v.dispose();
    }
    public static void ventanaCancelar(){
        vCanc = new VCancelar();
        vCanc.setVisible(true);
        vCanc.setLocationRelativeTo(null);
    }
    
    public static void ventanaModificar(){
        vMod = new VModificar();
        vMod.setVisible(true);
        vMod.setLocationRelativeTo(null);
    }
}
